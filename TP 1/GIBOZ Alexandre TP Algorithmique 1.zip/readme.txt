6 - Y a-t-il un cas où l'insertion puis la recherche est significamment plus rapide dans un tableau non trié ? 

Oui, l'unique cas ou ce scénario se produit est le test 10.


Pourquoi ?

Cela est du au fait que le nombre à trouver peut être présent dès le début du tablea non-trié.
Cela réduit donc considérablement le temps de réponse, car il suffit de parcourir qu'une poignée de cases.